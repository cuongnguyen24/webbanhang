<?php

// change the name below for the folder you want
$foldername = 'bo-di-choi-bien';
$dir = $_SERVER['DOCUMENT_ROOT'] . '/webbanhang/products/' .  $foldername ;

$file_to_write = 'index.php';
$content_to_write = '
<?php
session_start();
$username = $_SESSION["username"]; // Lấy tên tài khoản từ session
require_once "../admin/connect.php";

// Lấy dữ liệu từ CSDL
// GROUP_CONCAT - kết hợp tất cả các kích cỡ (size) của mỗi sản phẩm thành một chuỗi, ngăn cách bởi dấu phẩy
// ORDER BY size.tenSize sắp xếp các kích cỡ theo thứ tự tăng dần.
$sql = "SELECT sanpham.*, GROUP_CONCAT(size.tenSize ORDER BY size.tenSize SEPARATOR \', \') as sizes, anhSanPham.duongDanAnh 
        FROM sanpham
        INNER JOIN sizesanpham ON sanpham.maSanPham = sizesanpham.maSanPham
        INNER JOIN size ON sizesanpham.maSize = size.maSize
        INNER JOIN anhSanPham ON sanpham.maSanPham = anhSanPham.maSanPham
        GROUP BY maAnh";
$result = mysqli_query($conn, $sql);
$sanphams = [];
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $sanphams[] = $row;
    }
}

// Lấy maKhachHang theo bảng taikhoan dựa vào username
$sql_get_khachHang = "SELECT khachhang.maKhachHang FROM khachhang 
                    INNER JOIN taikhoan ON khachhang.maTaiKhoan = taikhoan.maTaiKhoan
                    WHERE tenTaiKhoan = \'$username\'";
$result_maKhachHang = mysqli_query($conn, $sql_get_khachHang);
if (mysqli_num_rows($result_maKhachHang) > 0) {
    $row_maKhachHang = mysqli_fetch_assoc($result_maKhachHang); // Sửa tên biến từ $result_maKhachHang thành $row_maKhachHang
    $maKhachHang = $row_maKhachHang["maKhachHang"];
} else {
    // Xử lý khi không tìm thấy tên tài khoản (username) trong bảng taikhoan
    die("Không tìm thấy tên tài khoản trong CSDL");
}

// Xử lý gửi kết quả qua cart.php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $maSanPham = $_POST["maSanPham"];
    $tenSanPham = $_POST["tenSanPham"];
    $giaBan = $_POST["giaBan"];
    $duongDanAnh = $_POST["duongDanAnh"];
    $size = $_POST["size"];
    $quantity = $_POST["quantity"];

    // Kiểm tra xem sản phẩm đã tồn tại trong giỏ hàng của người dùng hay chưa
    $sql_check = "SELECT * FROM giohang WHERE maKhachHang = \'$maKhachHang\' AND maSanPham = \'$maSanPham\' AND maSize = \'$size\'";
    $result_check = mysqli_query($conn, $sql_check);

    if (mysqli_num_rows($result_check) > 0) {
        // Nếu sản phẩm đã tồn tại, cập nhật số lượng
        $sql_update = "UPDATE giohang SET soLuong = soLuong + $quantity WHERE maKhachHang = \'$maKhachHang\' AND maSanPham = \'$maSanPham\' AND maSize = \'$size\'";
        mysqli_query($conn, $sql_update);
    } else {
        // Nếu sản phẩm chưa tồn tại, thêm mới vào giỏ hàng
        $sql_insert = "INSERT INTO giohang (maKhachHang, maSanPham, maSize, soLuong) 
                      VALUES (\'$maKhachHang\', \'$maSanPham\', \'$size\', $quantity)";
        mysqli_query($conn, $sql_insert);
    }

    // Chuyển hướng về trang giỏ hàng
    header("Location: ./cart.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Khách hàng</title>
<link rel="stylesheet" href="/webbanhang/assets/style.css" />
<link rel="stylesheet" href="/webbanhang/assets/reset.css" />
<link rel="stylesheet" href="../assets/cuongstyle.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="/webbanhang/assets/w3.css">
</head>
<body>
<?php
include ($_SERVER["DOCUMENT_ROOT"] . "/webbanhang/collections/includes/login.php");
include($_SERVER["DOCUMENT_ROOT"] . "/webbanhang/collections/includes/header.php");
?>
<div class="main-layout">
    <div class="collection template-collection">
        <div class="breadcrum-shop ">
            <div class="breadcrum-wrap container container-xl">
                <ol class="breadcrum">
                    <li class="breadcrum-item">
                        <a href="">Trang chủ</a>
                    </li>
                    <li class="breadcrum-item">
                        <span style="padding-right: 12px;">/</span>
                        <a href=""><span>Trẻ sơ sinh bộ dài tay</span></a>
                    </li>
                    <li class="breadcrum-item active">
                        <span style="padding-right: 12px;">/</span>
                        <span>Bộ liền dài màu be phối trắng in hình con mèo</span>
                    </li>
                </ol>
            </div>
        </div>
        <div class="container">
            <div class="productWrap">
                <div class="productWrapAll">
                    <div class="productWrapLeft">
                        <div class="w3-container">
                        </div>
                        <div class="w3-content" style="max-width:546px">
                            <img class="mySlides" src="//product.hstatic.net/200000692427/product/bo_lien_dai_mau_be_phoi_trang_in_hinh_con_meo_74fad5f6250d4ed9a38dbd7c7b395568_master.jpg" style="width:100%;display:none">
                            <img class="mySlides" src="//product.hstatic.net/200000692427/product/bo_lien_coc_mau_xanh_da_troi_b3fe0c6792494eb8bee9adeb6a435526_master.jpg" style="width:100%">
                            <img class="mySlides" src="//product.hstatic.net/200000692427/product/nous_-_nu_basic_-_nb2s24-op1-m01-pb_-_bo_lien_coc_mau_xanh_da_troi__3__daaf49b58e2b4f038ce146c46ac6bfec_master.jpg" style="width:100%;display:none">
                            <div class=" w3-section in-row" style="width: 556px;">
                                <div class="w3-col ">
                                    <img class="demo w3-opacity w3-hover-opacity-off" src="//product.hstatic.net/200000692427/product/bo_lien_dai_mau_be_phoi_trang_in_hinh_con_meo_74fad5f6250d4ed9a38dbd7c7b395568_master.jpg" style="width:121px;cursor:pointer" onclick="currentDiv(1)">
                                </div>
                                <div class="w3-col">
                                    <img class="demo w3-opacity w3-hover-opacity-off" src="//product.hstatic.net/200000692427/product/bo_lien_coc_mau_xanh_da_troi_b3fe0c6792494eb8bee9adeb6a435526_master.jpg" style="width:121px;cursor:pointer" onclick="currentDiv(2)">
                                </div>
                                <div class="w3-col">
                                    <img class="demo w3-opacity w3-hover-opacity-off" src="//product.hstatic.net/200000692427/product/nous_-_nu_basic_-_nb2s24-op1-m01-pb_-_bo_lien_coc_mau_xanh_da_troi__3__daaf49b58e2b4f038ce146c46ac6bfec_master.jpg" style="width:121px;cursor:pointer" onclick="currentDiv(3)">
                                </div>
                                <div class="w3-col">
                                    <img class="demo w3-opacity w3-hover-opacity-off" src="//product.hstatic.net/200000692427/product/nous_-_nu_basic_-_nb2s24-op1-m01-pb_-_bo_lien_coc_mau_xanh_da_troi__3__daaf49b58e2b4f038ce146c46ac6bfec_master.jpg" style="width:121px;cursor:pointer" onclick="currentDiv(3)">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="productWrapRight">
                        <div class="productWrapDetail">
                            <div class="productWrapDetailTitle">
                                <h1 class="productTitle">Bộ liền dài màu be phối trắng in hình con mèo</h1>
                            </div>
                            <div class="productPrice" style="color:#FF0000;">
                                699,000₫
                            </div>
                            <form class="addToCartForm" action="product.php" method="POST">
                                <input type="hidden" name="maSanPham" value="MSP001" />
                                <input type="hidden" name="tenSanPham" value="Bộ liền dài màu be phối trắng in hình con mèo" />
                                <input type="hidden" name="giaBan" value="699000" />
                                <input type="hidden" name="duongDanAnh" value="//product.hstatic.net/200000692427/product/bo_lien_dai_mau_be_phoi_trang_in_hinh_con_meo_74fad5f6250d4ed9a38dbd7c7b395568_master.jpg" />
                                <div class="productWrapDetailSize">
                                    <label for="size">Chọn kích cỡ:</label>
                                    <select name="size" id="size" class="form-control">
                                        <option value="1">S</option>
                                        <option value="2">M</option>
                                        <option value="3">L</option>
                                        <option value="4">XL</option>
                                    </select>
                                </div>
                                <div class="productWrapDetailQuantity">
                                    <label for="quantity">Số lượng:</label>
                                    <input type="number" name="quantity" id="quantity" value="1" min="1" class="form-control" />
                                </div>
                                <div class="productWrapDetailButton">
                                    <button type="submit" class="btnAddToCart">Thêm vào giỏ hàng</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="productDescription">
                    <h2>Mô tả sản phẩm</h2>
                    <p>Bộ liền dài màu be phối trắng in hình con mèo là sản phẩm tuyệt vời cho trẻ sơ sinh. Sản phẩm được làm từ chất liệu vải cao cấp, mềm mại và thoáng mát, giúp bé cảm thấy dễ chịu suốt cả ngày.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function currentDiv(n) {
    var i;
    var x = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("demo");
    if (n > x.length) {n = 1}
    if (n < 1) {n = x.length}
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
       dots[i].className = dots[i].className.replace(" w3-opacity-off", "");
    }
    x[n-1].style.display = "block";
    dots[n-1].className += " w3-opacity-off";
}
</script>
</body>
</html>
';
echo $dir . '/' .$file_to_write;
if( is_dir($dir) === false )
{
    mkdir($dir);
}

$file = fopen($dir . '/' . $file_to_write,"w");

// a different way to write content into
// fwrite($file,"Hello World.");

fwrite($file, $content_to_write);

// closes the file
fclose($file);

// this will show the created file from the created folder on screen
include $dir . '/' . $file_to_write;


?>