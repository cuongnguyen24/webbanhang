
<?php
$newFolderName = 'example_folder';
$directory = 'Applications/XAMPP/xamppfiles/htdocs/webbanhang/' . $newFolderName;

if (!file_exists($directory)) {
    $command = "mkdir -p " . escapeshellarg($directory);
    exec($command, $output, $return_var);
    
    if ($return_var === 0) {
        echo "Thư mục '$newFolderName' đã được tạo thành công.";
    } else {
        echo "Không thể tạo thư mục '$newFolderName'. Lỗi: " . implode("\n", $output);
    }
} else {
    echo "Thư mục '$newFolderName' đã tồn tại.";
}
?>